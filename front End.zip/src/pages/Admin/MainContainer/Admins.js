import Profile1 from '../../../images/Admin/profile-1.png';
import Profile2 from '../../../images/Admin/profile-2.png';
import Profile3 from '../../../images/Admin/profile-3.png';
import Profile4 from '../../../images/Admin/profile-4.png';
import Profile5 from '../../../images/Admin/profile-5.png';
import Profile6 from '../../../images/Admin/profile-6.png';
import Profile7 from '../../../images/Admin/profile-7.png';
import Profile8 from '../../../images/Admin/profile-8.png';
import Profile9 from '../../../images/Admin/profile-9.png';

const Admins = [
    {id : 1, admin_name : "Gilles Alain", imgSrc : Profile1},
    {id : 2, admin_name : "Armel Norbert", imgSrc : Profile2},
    {id : 3, admin_name : "Rhina", imgSrc : Profile3},
    {id : 4, admin_name : "Sosthenes", imgSrc : Profile4},
    {id : 5, admin_name : "Prince Lewis", imgSrc : Profile5},
    {id : 6, admin_name : "Dambové Kévin", imgSrc : Profile6},
    {id : 7, admin_name : "Anyva", imgSrc : Profile7},
    {id : 8, admin_name : "Laeticia", imgSrc : Profile8},
    {id : 9, admin_name : "Patricia", imgSrc : Profile9}
];

export default Admins;