import React from 'react';
import Form from './addlogements/form.jsx';
import { Link } from 'react-router-dom';

function AddLogement() {
  return (
    <div className='addLogement'>
        <Link to=''>Ajouter un bien</Link>
    </div>
  )
}

export default AddLogement;